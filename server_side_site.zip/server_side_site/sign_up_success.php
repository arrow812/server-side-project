<?php

require_once('includes/header.php');


$sHTML= '<section id="about" class="container content-section text-center">
        <div class="row">
            <div class="col-lg-8 col-lg-offset-2">
                <h2>Great! now log in and Upload your favorite photos</h2>
                
            </div>
        </div>
    </section>';

echo $sHTML;




require_once('includes/footer.php');