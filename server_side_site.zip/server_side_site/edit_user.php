<?php

require_once('includes/header.php');

?>


<div class="container">
  
  
  <table class="table ">

 
    <h3>MEMBER DETAILS</h3>
      

    <tbody>
      <tr>
        <td>First Name</td>
        <td>Aramis</td>
      </tr>
      <tr>
        <td>Last Name</td>
        <td>Goodwin</td>
      </tr>
      <tr>
        <td>Email</td>
        <td>email@here.com</td>
      </tr>
    </tbody>


  </table>

   <button type="submit" class=" member-btn btn btn-primary">Edit</button>
</div>




<?php
require_once('includes/footer.php');
?>