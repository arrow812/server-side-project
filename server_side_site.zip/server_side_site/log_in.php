<?php

require_once('includes/header.php');

?>



    <form class="form">
  <h3>LOG IN</h3>
  <fieldset class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email">
  </fieldset>
  
  <fieldset class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
  </fieldset>
  
  
 
 
  
  
  <button type="submit" class="btn btn-primary">Submit</button>
</form>


<?php
require_once('includes/footer.php');
?>